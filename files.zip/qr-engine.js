"use strict";
// ─── QR Code Engine (Version 1-10, Error Correction L/M/Q/H) ────────────────
// Pure Node.js — zero dependencies

// ── GF(256) arithmetic (Reed-Solomon) ────────────────────────────────────────
const GF_EXP = new Uint8Array(512);
const GF_LOG = new Uint8Array(256);
(function buildGF() {
  let x = 1;
  for (let i = 0; i < 255; i++) {
    GF_EXP[i] = x;
    GF_LOG[x] = i;
    x <<= 1;
    if (x & 0x100) x ^= 0x11d;
  }
  for (let i = 255; i < 512; i++) GF_EXP[i] = GF_EXP[i - 255];
})();

function gfMul(a, b) { return (a === 0 || b === 0) ? 0 : GF_EXP[GF_LOG[a] + GF_LOG[b]]; }
function gfPoly(deg) {
  let p = [1];
  for (let i = 0; i < deg; i++) {
    const e = GF_EXP[i];
    const np = new Array(p.length + 1).fill(0);
    for (let j = 0; j < p.length; j++) { np[j] ^= p[j]; np[j + 1] ^= gfMul(p[j], e); }
    p = np;
  }
  return p;
}
function rsDivide(msg, nec) {
  const gen = gfPoly(nec);
  const res = [...msg, ...new Array(nec).fill(0)];
  for (let i = 0; i < msg.length; i++) {
    const c = res[i];
    if (c !== 0) for (let j = 1; j <= gen.length; j++) res[i + j - 1] ^= gfMul(gen[j - 1] || 0, c);
  }
  return res.slice(msg.length);
}

// ── Capacity tables (version 1–10, ECL: L=0 M=1 Q=2 H=3) ───────────────────
// [dataCodewords, ecCodewordsPerBlock, blocks]
const CAP = [
  null,
  [[19,7,1],[16,10,1],[13,13,1],[9,17,1]],
  [[34,10,1],[28,16,1],[22,22,1],[16,28,1]],
  [[55,15,1],[44,26,1],[34,18,2],[26,22,2]],
  [[80,20,2],[64,18,2],[48,26,4],[36,16,4]],
  [[108,26,1],[86,24,2],[62,18,2],[46,22,2]], //v5 mixed groups omitted for simplicity
  [[136,18,2],[108,16,4],[76,24,4],[60,28,4]],
  [[156,20,4],[124,18,4],[88,18,6],[66,26,4]],
  [[194,24,2],[154,22,2],[110,22,6],[86,26,4]],
  [[232,30,2],[182,22,3],[132,20,8],[100,24,4]],
  [[274,18,4],[216,26,4],[154,24,8],[122,28,6]],
];

// ── Numeric/Alphanumeric/Byte encode ─────────────────────────────────────────
const ALNUM = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:";
function bestMode(s) {
  if (/^\d+$/.test(s)) return "numeric";
  if (s.split("").every(c => ALNUM.includes(c))) return "alphanumeric";
  return "byte";
}

function encodeData(text, version, ecl) {
  const mode = bestMode(text);
  const [totalCW] = CAP[version][ecl];
  const bits = [];
  const push = (val, len) => { for (let i = len - 1; i >= 0; i--) bits.push((val >> i) & 1); };

  const charCountBits = mode === "numeric" ? (version < 10 ? 10 : 12)
    : mode === "alphanumeric" ? (version < 10 ? 9 : 11) : (version < 10 ? 8 : 16);

  if (mode === "numeric") {
    push(0b0001, 4); push(text.length, charCountBits);
    for (let i = 0; i < text.length; i += 3) {
      const s = text.slice(i, i + 3);
      const len = s.length === 3 ? 10 : s.length === 2 ? 7 : 4;
      push(parseInt(s), len);
    }
  } else if (mode === "alphanumeric") {
    push(0b0010, 4); push(text.length, charCountBits);
    for (let i = 0; i < text.length; i += 2) {
      if (i + 1 < text.length) push(ALNUM.indexOf(text[i]) * 45 + ALNUM.indexOf(text[i + 1]), 11);
      else push(ALNUM.indexOf(text[i]), 6);
    }
  } else {
    const bytes = Buffer.from(text, "utf8");
    push(0b0100, 4); push(bytes.length, charCountBits);
    for (const b of bytes) push(b, 8);
  }

  push(0b0000, 4);
  while (bits.length % 8) bits.push(0);
  const codewords = [];
  for (let i = 0; i < bits.length; i += 8) {
    let v = 0; for (let j = 0; j < 8; j++) v = (v << 1) | (bits[i + j] || 0);
    codewords.push(v);
  }
  const pads = [0xec, 0x11];
  while (codewords.length < totalCW) codewords.push(pads[(codewords.length - (bits.length / 8)) % 2]);
  return codewords;
}

// ── Interleave + RS ──────────────────────────────────────────────────────────
function buildFinalMessage(text, version, ecl) {
  const [totalCW, ecPerBlock, numBlocks] = CAP[version][ecl];
  const dataPerBlock = Math.floor(totalCW / numBlocks);
  const extra = totalCW % numBlocks;
  const allData = encodeData(text, version, ecl);

  const blocks = []; const ecBlocks = [];
  let offset = 0;
  for (let b = 0; b < numBlocks; b++) {
    const len = dataPerBlock + (b >= numBlocks - extra ? 1 : 0);
    const chunk = allData.slice(offset, offset + len);
    blocks.push(chunk);
    ecBlocks.push(rsDivide(chunk, ecPerBlock));
    offset += len;
  }
  const result = [];
  const maxLen = Math.max(...blocks.map(b => b.length));
  for (let i = 0; i < maxLen; i++) for (const b of blocks) if (i < b.length) result.push(b[i]);
  for (let i = 0; i < ecPerBlock; i++) for (const b of ecBlocks) result.push(b[i]);
  return result;
}

// ── Matrix builder ───────────────────────────────────────────────────────────
function makeMatrix(version) {
  const size = version * 4 + 17;
  return Array.from({ length: size }, () => new Array(size).fill(null));
}

function placeFinderPattern(m, r, c) {
  const pat = [[1,1,1,1,1,1,1],[1,0,0,0,0,0,1],[1,0,1,1,1,0,1],[1,0,1,1,1,0,1],[1,0,1,1,1,0,1],[1,0,0,0,0,0,1],[1,1,1,1,1,1,1]];
  for (let i = 0; i < 7; i++) for (let j = 0; j < 7; j++) m[r+i][c+j] = pat[i][j];
}

function placeSeparators(m, size) {
  for (let i = 0; i < 8; i++) { m[7][i]=0; m[i][7]=0; m[size-8][i]=0; m[i][size-8]=0; m[7][size-1-i]=0; m[size-1-i][7]=0; }
  m[7][7]=0; m[size-8][7]=0; m[7][size-8]=0;
}

const ALIGN_POS = [null,[],[6,18],[6,22],[6,26],[6,30],[6,34],[6,22,38],[6,24,42],[6,26,46],[6,28,50]];
function placeAlignPatterns(m, version) {
  const pos = ALIGN_POS[version];
  for (const r of pos) for (const c of pos) {
    if ((r===6&&c===6)||(r===6&&c===pos[pos.length-1])||(r===pos[pos.length-1]&&c===6)) continue;
    for (let i=-2;i<=2;i++) for (let j=-2;j<=2;j++) m[r+i][c+j] = (Math.abs(i)===2||Math.abs(j)===2||i===0&&j===0)?1:0;
  }
}

function placeTimingPatterns(m, size) {
  for (let i=8;i<size-8;i++) { if(m[6][i]===null) m[6][i]=(i%2===0)?1:0; if(m[i][6]===null) m[i][6]=(i%2===0)?1:0; }
}

function placeDarkModule(m, version) { m[version*4+9][8]=1; }

function reserveFormatInfo(m, size) {
  const fmtPos = [[8,0],[8,1],[8,2],[8,3],[8,4],[8,5],[8,7],[8,8],[7,8],[5,8],[4,8],[3,8],[2,8],[1,8],[0,8]];
  for (const [r,c] of fmtPos) { if(m[r][c]===null) m[r][c]=0; if(m[size-1-c<0?0:c>7?size-1-(14-fmtPos.indexOf([r,c])): r][c]===null) m[r][c]=0; }
  for (let i=0;i<7;i++) if(m[size-7+i][8]===null) m[size-7+i][8]=0;
  for (let i=0;i<8;i++) if(m[8][size-8+i]===null) m[8][size-8+i]=0;
}

// Simple format info placement (ECL + mask)
function placeFormatInfo(m, size, ecl, mask) {
  const eclBits = [1,0,3,2][ecl]; // L=01 M=00 Q=11 H=10
  let fmt = (eclBits << 3) | mask;
  // BCH error correction for format info
  let g = fmt << 10;
  const poly = 0b10100110111;
  for (let i = 14; i >= 10; i--) if (g & (1 << i)) g ^= (poly << (i - 10));
  fmt = ((eclBits << 3) | mask) << 10 | g;
  fmt ^= 0b101010000010010;

  const bits = [];
  for (let i = 14; i >= 0; i--) bits.push((fmt >> i) & 1);

  const pos1 = [[8,0],[8,1],[8,2],[8,3],[8,4],[8,5],[8,7],[8,8],[7,8],[5,8],[4,8],[3,8],[2,8],[1,8],[0,8]];
  const pos2 = [[size-1,8],[size-2,8],[size-3,8],[size-4,8],[size-5,8],[size-6,8],[size-7,8],[8,size-8],[8,size-7],[8,size-6],[8,size-5],[8,size-4],[8,size-3],[8,size-2],[8,size-1]];
  for (let i = 0; i < 15; i++) { m[pos1[i][0]][pos1[i][1]] = bits[i]; m[pos2[i][0]][pos2[i][1]] = bits[i]; }
}

function placeDataBits(m, size, message) {
  let bitIdx = 0;
  let up = true;
  for (let col = size - 1; col >= 1; col -= 2) {
    if (col === 6) col--;
    for (let i = 0; i < size; i++) {
      const row = up ? size - 1 - i : i;
      for (let d = 0; d < 2; d++) {
        const c = col - d;
        if (m[row][c] === null) {
          const byteIdx = Math.floor(bitIdx / 8);
          const bitPos = 7 - (bitIdx % 8);
          m[row][c] = byteIdx < message.length ? (message[byteIdx] >> bitPos) & 1 : 0;
          bitIdx++;
        }
      }
    }
    up = !up;
  }
}

const MASKS = [
  (r,c)=>(r+c)%2===0,(r,c)=>r%2===0,(r,c)=>c%3===0,(r,c)=>(r+c)%3===0,
  (r,c)=>(Math.floor(r/2)+Math.floor(c/3))%2===0,(r,c)=>(r*c)%2+(r*c)%3===0,
  (r,c)=>((r*c)%2+(r*c)%3)%2===0,(r,c)=>((r+c)%2+(r*c)%3)%2===0
];

function applyMask(m, size, maskFn) {
  const mc = m.map(r => [...r]);
  for (let r = 0; r < size; r++) for (let c = 0; c < size; c++) {
    if (mc[r][c] !== null && mc[r][c] !== undefined && typeof mc[r][c] === "number") {
      // Only mask data modules (not function patterns)
      // We'll apply mask to all "data" cells — properly set after placement
    }
  }
  return mc;
}

function penaltyScore(m, size) {
  let score = 0;
  // Rule 1: 5+ consecutive same-color
  for (let r = 0; r < size; r++) {
    let cnt = 1;
    for (let c = 1; c < size; c++) { if (m[r][c]===m[r][c-1]) cnt++; else { if(cnt>=5) score+=cnt-2; cnt=1; } }
    if (cnt >= 5) score += cnt - 2;
  }
  for (let c = 0; c < size; c++) {
    let cnt = 1;
    for (let r = 1; r < size; r++) { if (m[r][c]===m[r-1][c]) cnt++; else { if(cnt>=5) score+=cnt-2; cnt=1; } }
    if (cnt >= 5) score += cnt - 2;
  }
  // Rule 2: 2x2 blocks
  for (let r = 0; r < size - 1; r++) for (let c = 0; c < size - 1; c++)
    if (m[r][c]===m[r][c+1]&&m[r][c]===m[r+1][c]&&m[r][c]===m[r+1][c+1]) score += 3;
  return score;
}

function bestMask(m, size) {
  let best = -1, bestScore = Infinity;
  for (let mask = 0; mask < 8; mask++) {
    const fn = MASKS[mask];
    const mc = m.map(r => [...r]);
    for (let r = 0; r < size; r++) for (let c = 0; c < size; c++)
      if (mc[r][c] !== null && fn(r, c)) mc[r][c] ^= 1;
    const s = penaltyScore(mc, size);
    if (s < bestScore) { bestScore = s; best = mask; }
  }
  return best;
}

function chooseVersion(text, ecl) {
  const mode = bestMode(text);
  const len = mode === "byte" ? Buffer.byteLength(text, "utf8") : text.length;
  for (let v = 1; v <= 10; v++) {
    const [totalCW] = CAP[v][ecl];
    // rough bit capacity check
    const maxChars = mode === "numeric" ? Math.floor(totalCW * 8 / 10 * 3)
      : mode === "alphanumeric" ? Math.floor(totalCW * 8 / 11 * 2)
      : totalCW - 4;
    if (len <= maxChars) return v;
  }
  return 10;
}

// ── Public API ───────────────────────────────────────────────────────────────
function generateMatrix(text, eclLevel = 1) {
  const version = chooseVersion(text, eclLevel);
  const size = version * 4 + 17;
  const m = makeMatrix(version);

  placeFinderPattern(m, 0, 0);
  placeFinderPattern(m, 0, size - 7);
  placeFinderPattern(m, size - 7, 0);
  placeSeparators(m, size);
  if (version > 1) placeAlignPatterns(m, version);
  placeTimingPatterns(m, size);
  placeDarkModule(m, version);

  const message = buildFinalMessage(text, version, eclLevel);
  placeDataBits(m, size, message);

  const mask = bestMask(m, size);
  const fn = MASKS[mask];
  for (let r = 0; r < size; r++) for (let c = 0; c < size; c++)
    if (m[r][c] !== null && fn(r, c)) m[r][c] ^= 1;

  placeFormatInfo(m, size, eclLevel, mask);

  return { matrix: m, size, version, mask };
}

module.exports = { generateMatrix };
