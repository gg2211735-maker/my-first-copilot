import { drivers } from '../src/data.js'

let db = [...drivers]
let nextId = db.length + 1

export async function driverRoutes(fastify) {
  // GET /drivers — lista todos (suporta ?active=true/false e ?team=)
  fastify.get('/drivers', async (req, reply) => {
    let result = db

    if (req.query.active !== undefined) {
      const active = req.query.active === 'true'
      result = result.filter(d => d.active === active)
    }

    if (req.query.team) {
      result = result.filter(d =>
        d.team.toLowerCase().includes(req.query.team.toLowerCase())
      )
    }

    return reply.send(result)
  })

  // GET /drivers/:id
  fastify.get('/drivers/:id', async (req, reply) => {
    const driver = db.find(d => d.id === Number(req.params.id))
    if (!driver) return reply.status(404).send({ error: 'Piloto não encontrado.' })
    return reply.send(driver)
  })

  // POST /drivers
  fastify.post('/drivers', {
    schema: {
      body: {
        type: 'object',
        required: ['name', 'team', 'nationality', 'number'],
        properties: {
          name:          { type: 'string' },
          team:          { type: 'string' },
          nationality:   { type: 'string' },
          number:        { type: 'number' },
          championships: { type: 'number', default: 0 },
          wins:          { type: 'number', default: 0 },
          podiums:       { type: 'number', default: 0 },
          active:        { type: 'boolean', default: true }
        }
      }
    }
  }, async (req, reply) => {
    const newDriver = { id: nextId++, ...req.body }
    db.push(newDriver)
    return reply.status(201).send(newDriver)
  })

  // PUT /drivers/:id
  fastify.put('/drivers/:id', async (req, reply) => {
    const idx = db.findIndex(d => d.id === Number(req.params.id))
    if (idx === -1) return reply.status(404).send({ error: 'Piloto não encontrado.' })
    db[idx] = { ...db[idx], ...req.body }
    return reply.send(db[idx])
  })

  // DELETE /drivers/:id
  fastify.delete('/drivers/:id', async (req, reply) => {
    const idx = db.findIndex(d => d.id === Number(req.params.id))
    if (idx === -1) return reply.status(404).send({ error: 'Piloto não encontrado.' })
    db.splice(idx, 1)
    return reply.status(204).send()
  })
}
