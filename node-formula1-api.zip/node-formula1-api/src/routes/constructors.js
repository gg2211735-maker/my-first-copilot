import { constructors } from '../data.js'

let db = [...constructors]
let nextId = db.length + 1

export async function constructorRoutes(fastify) {
  // GET /constructors
  fastify.get('/constructors', async (req, reply) => {
    let result = db

    if (req.query.country) {
      result = result.filter(c =>
        c.country.toLowerCase().includes(req.query.country.toLowerCase())
      )
    }

    return reply.send(result)
  })

  // GET /constructors/:id
  fastify.get('/constructors/:id', async (req, reply) => {
    const constructor = db.find(c => c.id === Number(req.params.id))
    if (!constructor) return reply.status(404).send({ error: 'Escuderia não encontrada.' })
    return reply.send(constructor)
  })

  // POST /constructors
  fastify.post('/constructors', {
    schema: {
      body: {
        type: 'object',
        required: ['name', 'country'],
        properties: {
          name:          { type: 'string' },
          country:       { type: 'string' },
          championships: { type: 'number', default: 0 },
          entries:       { type: 'number', default: 0 },
          wins:          { type: 'number', default: 0 }
        }
      }
    }
  }, async (req, reply) => {
    const newConstructor = { id: nextId++, ...req.body }
    db.push(newConstructor)
    return reply.status(201).send(newConstructor)
  })

  // PUT /constructors/:id
  fastify.put('/constructors/:id', async (req, reply) => {
    const idx = db.findIndex(c => c.id === Number(req.params.id))
    if (idx === -1) return reply.status(404).send({ error: 'Escuderia não encontrada.' })
    db[idx] = { ...db[idx], ...req.body }
    return reply.send(db[idx])
  })

  // DELETE /constructors/:id
  fastify.delete('/constructors/:id', async (req, reply) => {
    const idx = db.findIndex(c => c.id === Number(req.params.id))
    if (idx === -1) return reply.status(404).send({ error: 'Escuderia não encontrada.' })
    db.splice(idx, 1)
    return reply.status(204).send()
  })
}
