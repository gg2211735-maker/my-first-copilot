import Fastify from 'fastify'
import { driverRoutes } from './routes/drivers.js'
import { constructorRoutes } from './routes/constructors.js'

const fastify = Fastify({ logger: true })

// Health check
fastify.get('/', async (req, reply) => {
  return reply.send({
    message: '🏎️ Formula 1 API — Node.js + Fastify',
    version: '1.0.0',
    endpoints: {
      drivers:      '/drivers',
      constructors: '/constructors'
    }
  })
})

// Registrar rotas com prefixo /api
fastify.register(driverRoutes,      { prefix: '/api' })
fastify.register(constructorRoutes, { prefix: '/api' })

// Handler de erros global
fastify.setErrorHandler((error, req, reply) => {
  fastify.log.error(error)
  reply.status(error.statusCode || 500).send({
    error: error.message || 'Erro interno do servidor.'
  })
})

// Iniciar servidor
const PORT = process.env.PORT || 3000
const HOST = process.env.HOST || '0.0.0.0'

try {
  await fastify.listen({ port: PORT, host: HOST })
  console.log(`\n🏁 Servidor rodando em http://localhost:${PORT}`)
  console.log('📋 Endpoints disponíveis:')
  console.log(`   GET    http://localhost:${PORT}/api/drivers`)
  console.log(`   GET    http://localhost:${PORT}/api/drivers/:id`)
  console.log(`   POST   http://localhost:${PORT}/api/drivers`)
  console.log(`   PUT    http://localhost:${PORT}/api/drivers/:id`)
  console.log(`   DELETE http://localhost:${PORT}/api/drivers/:id`)
  console.log(`   GET    http://localhost:${PORT}/api/constructors`)
  console.log(`   GET    http://localhost:${PORT}/api/constructors/:id`)
  console.log(`   POST   http://localhost:${PORT}/api/constructors`)
  console.log(`   PUT    http://localhost:${PORT}/api/constructors/:id`)
  console.log(`   DELETE http://localhost:${PORT}/api/constructors/:id\n`)
} catch (err) {
  fastify.log.error(err)
  process.exit(1)
}
