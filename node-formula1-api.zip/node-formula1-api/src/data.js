export const drivers = [
  {
    id: 1,
    name: "Max Verstappen",
    team: "Red Bull Racing",
    nationality: "Holandesa",
    number: 1,
    championships: 3,
    wins: 57,
    podiums: 101,
    active: true
  },
  {
    id: 2,
    name: "Lewis Hamilton",
    team: "Ferrari",
    nationality: "Britânica",
    number: 44,
    championships: 7,
    wins: 103,
    podiums: 197,
    active: true
  },
  {
    id: 3,
    name: "Charles Leclerc",
    team: "Ferrari",
    nationality: "Monegasca",
    number: 16,
    championships: 0,
    wins: 5,
    podiums: 36,
    active: true
  },
  {
    id: 4,
    name: "Carlos Sainz",
    team: "Williams",
    nationality: "Espanhola",
    number: 55,
    championships: 0,
    wins: 3,
    podiums: 25,
    active: true
  },
  {
    id: 5,
    name: "Lando Norris",
    team: "McLaren",
    nationality: "Britânica",
    number: 4,
    championships: 0,
    wins: 4,
    podiums: 22,
    active: true
  },
  {
    id: 6,
    name: "George Russell",
    team: "Mercedes",
    nationality: "Britânica",
    number: 63,
    championships: 0,
    wins: 2,
    podiums: 14,
    active: true
  },
  {
    id: 7,
    name: "Fernando Alonso",
    team: "Aston Martin",
    nationality: "Espanhola",
    number: 14,
    championships: 2,
    wins: 32,
    podiums: 106,
    active: true
  },
  {
    id: 8,
    name: "Oscar Piastri",
    team: "McLaren",
    nationality: "Australiana",
    number: 81,
    championships: 0,
    wins: 2,
    podiums: 12,
    active: true
  },
  {
    id: 9,
    name: "Ayrton Senna",
    team: "McLaren",
    nationality: "Brasileira",
    number: 12,
    championships: 3,
    wins: 41,
    podiums: 80,
    active: false
  },
  {
    id: 10,
    name: "Michael Schumacher",
    team: "Ferrari",
    nationality: "Alemã",
    number: 1,
    championships: 7,
    wins: 91,
    podiums: 155,
    active: false
  }
]

export const constructors = [
  { id: 1, name: "Red Bull Racing", country: "Áustria", championships: 6, entries: 318, wins: 117 },
  { id: 2, name: "Ferrari",         country: "Itália",  championships: 16, entries: 1090, wins: 243 },
  { id: 3, name: "Mercedes",        country: "Alemanha", championships: 8, entries: 285, wins: 125 },
  { id: 4, name: "McLaren",         country: "Reino Unido", championships: 8, entries: 951, wins: 183 },
  { id: 5, name: "Aston Martin",    country: "Reino Unido", championships: 0, entries: 82, wins: 0 },
  { id: 6, name: "Williams",        country: "Reino Unido", championships: 9, entries: 803, wins: 114 }
]
