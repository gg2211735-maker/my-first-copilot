# 🏎️ Formula 1 API — Node.js + Fastify

API minimalista e eficiente para gerenciamento de dados da Fórmula 1, desenvolvida com **Node.js** e **Fastify**. Projeto entregue como desafio prático na plataforma [DIO](https://www.dio.me/), inspirado no repositório original [node-formula-1](https://github.com/digitalinnovationone/node-formula-1).

---

## 🚀 Tecnologias utilizadas

- [Node.js](https://nodejs.org/) — runtime JavaScript
- [Fastify](https://fastify.dev/) — framework web rápido e minimalista
- ES Modules (`"type": "module"`)
- JSON Schema para validação de entrada

---

## 📁 Estrutura do projeto

```
node-formula1-api/
├── src/
│   ├── index.js            # Servidor principal
│   ├── data.js             # Dados em memória (pilotos e escuderias)
│   └── routes/
│       ├── drivers.js      # Rotas CRUD de pilotos
│       └── constructors.js # Rotas CRUD de escuderias
├── .env
├── .gitignore
├── package.json
└── README.md
```

---

## ⚙️ Como executar localmente

### Pré-requisitos

- Node.js v18+ instalado
- npm

### Passo a passo

```bash
# 1. Clone o repositório
git clone https://github.com/seu-usuario/node-formula1-api.git
cd node-formula1-api

# 2. Instale as dependências
npm install

# 3. Execute em modo desenvolvimento (com hot reload)
npm run dev

# 4. Ou execute em produção
npm start
```

O servidor estará disponível em `http://localhost:3000`.

---

## 📋 Endpoints disponíveis

### Pilotos — `/api/drivers`

| Método | Rota               | Descrição                         |
|--------|--------------------|-----------------------------------|
| GET    | `/api/drivers`     | Lista todos os pilotos            |
| GET    | `/api/drivers/:id` | Busca piloto por ID               |
| POST   | `/api/drivers`     | Cria um novo piloto               |
| PUT    | `/api/drivers/:id` | Atualiza dados de um piloto       |
| DELETE | `/api/drivers/:id` | Remove um piloto                  |

**Query params disponíveis no GET /api/drivers:**
- `?active=true` — filtra por pilotos ativos
- `?team=Ferrari` — filtra por escuderia

### Escuderias — `/api/constructors`

| Método | Rota                     | Descrição                        |
|--------|--------------------------|----------------------------------|
| GET    | `/api/constructors`      | Lista todas as escuderias        |
| GET    | `/api/constructors/:id`  | Busca escuderia por ID           |
| POST   | `/api/constructors`      | Cria uma nova escuderia          |
| PUT    | `/api/constructors/:id`  | Atualiza dados de uma escuderia  |
| DELETE | `/api/constructors/:id`  | Remove uma escuderia             |

---

## 🧪 Exemplos de uso

### Listar todos os pilotos
```http
GET http://localhost:3000/api/drivers
```

### Filtrar pilotos ativos da McLaren
```http
GET http://localhost:3000/api/drivers?active=true&team=McLaren
```

### Criar novo piloto
```http
POST http://localhost:3000/api/drivers
Content-Type: application/json

{
  "name": "Gabriel Bortoleto",
  "team": "Sauber",
  "nationality": "Brasileira",
  "number": 5,
  "championships": 0,
  "wins": 0,
  "podiums": 0,
  "active": true
}
```

### Atualizar piloto
```http
PUT http://localhost:3000/api/drivers/1
Content-Type: application/json

{
  "wins": 60
}
```

### Deletar piloto
```http
DELETE http://localhost:3000/api/drivers/1
```

---

## 🆕 Melhorias em relação ao projeto original

- ✅ Dados separados em arquivo `data.js` (pilotos + escuderias)
- ✅ Rotas organizadas por módulo (`routes/drivers.js`, `routes/constructors.js`)
- ✅ Validação de schema com JSON Schema nativo do Fastify
- ✅ Query params para filtrar por escuderia e status ativo
- ✅ Handler global de erros
- ✅ Endpoint de health check na raiz `/`
- ✅ Mensagens de erro em português

---

## 🔗 Referências

- [Repositório original — DIO](https://github.com/digitalinnovationone/node-formula-1)
- [Documentação Fastify](https://fastify.dev/docs/latest/)
- [Plataforma DIO](https://www.dio.me/)

---

## 👨‍💻 Autor

Desenvolvido como parte do bootcamp Node.js na **DIO — Digital Innovation One**.
