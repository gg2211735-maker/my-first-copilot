import express from 'express'
import cors from 'cors'
import gamesRouter from './routes/games.js'
import { requestLogger } from './middlewares/logger.js'
import { notFound, errorHandler } from './middlewares/errorHandler.js'

const app = express()
const PORT = process.env.PORT || 3000

app.use(cors())
app.use(express.json())
app.use(requestLogger)

app.get('/', (req, res) => {
  res.json({
    message: '🎮 Games Library API — Node.js + Express',
    version: '1.0.0',
    endpoints: {
      'GET    /api/games':              'Listar jogos (filtros: ?genre, ?platform, ?completed, ?sort=rating)',
      'GET    /api/games/:id':          'Buscar jogo por ID',
      'POST   /api/games':              'Cadastrar novo jogo',
      'PUT    /api/games/:id':          'Atualizar jogo',
      'PATCH  /api/games/:id/complete': 'Alternar status de conclusão',
      'DELETE /api/games/:id':          'Remover jogo'
    }
  })
})

app.use('/api/games', gamesRouter)

app.use(notFound)
app.use(errorHandler)

app.listen(PORT, () => {
  console.log(`\n🎮 Games Library API rodando em http://localhost:${PORT}\n`)
})

export default app
