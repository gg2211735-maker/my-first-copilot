import { v4 as uuidv4 } from 'uuid'
import { games } from '../data/games.js'

// GET /api/games
export function listGames(req, res) {
  let result = [...games]

  // Filtros opcionais via query params
  if (req.query.genre) {
    result = result.filter(g =>
      g.genre.toLowerCase().includes(req.query.genre.toLowerCase())
    )
  }

  if (req.query.platform) {
    result = result.filter(g =>
      g.platform.toLowerCase().includes(req.query.platform.toLowerCase())
    )
  }

  if (req.query.completed !== undefined) {
    const completed = req.query.completed === 'true'
    result = result.filter(g => g.completed === completed)
  }

  // Ordenação por rating
  if (req.query.sort === 'rating') {
    result.sort((a, b) => b.rating - a.rating)
  }

  return res.status(200).json({
    total: result.length,
    data: result
  })
}

// GET /api/games/:id
export function getGame(req, res) {
  const game = games.find(g => g.id === req.params.id)

  if (!game) {
    return res.status(404).json({ error: 'Jogo não encontrado.' })
  }

  return res.status(200).json(game)
}

// POST /api/games
export function createGame(req, res) {
  const { title, genre, platform, developer, releaseYear, rating } = req.body

  if (!title || !genre || !platform || !developer) {
    return res.status(400).json({
      error: 'Campos obrigatórios: title, genre, platform, developer.'
    })
  }

  if (rating && (rating < 0 || rating > 10)) {
    return res.status(400).json({ error: 'Rating deve ser entre 0 e 10.' })
  }

  const newGame = {
    id: uuidv4(),
    title,
    genre,
    platform,
    developer,
    releaseYear: releaseYear || null,
    rating: rating || null,
    completed: false
  }

  games.push(newGame)

  return res.status(201).json(newGame)
}

// PUT /api/games/:id
export function updateGame(req, res) {
  const idx = games.findIndex(g => g.id === req.params.id)

  if (idx === -1) {
    return res.status(404).json({ error: 'Jogo não encontrado.' })
  }

  const { rating } = req.body

  if (rating && (rating < 0 || rating > 10)) {
    return res.status(400).json({ error: 'Rating deve ser entre 0 e 10.' })
  }

  games[idx] = { ...games[idx], ...req.body, id: games[idx].id }

  return res.status(200).json(games[idx])
}

// PATCH /api/games/:id/complete
export function toggleComplete(req, res) {
  const game = games.find(g => g.id === req.params.id)

  if (!game) {
    return res.status(404).json({ error: 'Jogo não encontrado.' })
  }

  game.completed = !game.completed

  return res.status(200).json({
    message: `Jogo marcado como ${game.completed ? 'concluído' : 'não concluído'}.`,
    game
  })
}

// DELETE /api/games/:id
export function deleteGame(req, res) {
  const idx = games.findIndex(g => g.id === req.params.id)

  if (idx === -1) {
    return res.status(404).json({ error: 'Jogo não encontrado.' })
  }

  games.splice(idx, 1)

  return res.status(204).send()
}
