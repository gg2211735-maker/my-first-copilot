import { v4 as uuidv4 } from 'uuid'

export let games = [
  {
    id: uuidv4(),
    title: 'The Last of Us Part II',
    genre: 'Ação/Aventura',
    platform: 'PlayStation',
    developer: 'Naughty Dog',
    releaseYear: 2020,
    rating: 9.5,
    completed: true
  },
  {
    id: uuidv4(),
    title: 'Hollow Knight',
    genre: 'Metroidvania',
    platform: 'Multi',
    developer: 'Team Cherry',
    releaseYear: 2017,
    rating: 9.2,
    completed: false
  },
  {
    id: uuidv4(),
    title: 'Elden Ring',
    genre: 'RPG/Ação',
    platform: 'Multi',
    developer: 'FromSoftware',
    releaseYear: 2022,
    rating: 9.8,
    completed: false
  },
  {
    id: uuidv4(),
    title: 'Celeste',
    genre: 'Plataforma',
    platform: 'Multi',
    developer: 'Maddy Thorson',
    releaseYear: 2018,
    rating: 9.0,
    completed: true
  },
  {
    id: uuidv4(),
    title: 'Cyberpunk 2077',
    genre: 'RPG/Ação',
    platform: 'Multi',
    developer: 'CD Projekt Red',
    releaseYear: 2020,
    rating: 8.7,
    completed: false
  },
  {
    id: uuidv4(),
    title: 'Hades',
    genre: 'Roguelike',
    platform: 'Multi',
    developer: 'Supergiant Games',
    releaseYear: 2020,
    rating: 9.6,
    completed: true
  }
]
