// Middleware para rotas não encontradas
export function notFound(req, res, next) {
  const error = new Error(`Rota não encontrada — ${req.originalUrl}`)
  res.status(404)
  next(error)
}

// Middleware global de tratamento de erros
export function errorHandler(err, req, res, next) {
  const statusCode = res.statusCode !== 200 ? res.statusCode : 500

  return res.status(statusCode).json({
    error: err.message,
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  })
}
