import { Router } from 'express'
import {
  listGames,
  getGame,
  createGame,
  updateGame,
  toggleComplete,
  deleteGame
} from '../controllers/gamesController.js'

const router = Router()

router.get('/',          listGames)
router.get('/:id',       getGame)
router.post('/',         createGame)
router.put('/:id',       updateGame)
router.patch('/:id/complete', toggleComplete)
router.delete('/:id',    deleteGame)

export default router
