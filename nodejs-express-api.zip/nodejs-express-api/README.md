# 🎮 Games Library API — Node.js + Express

API REST para gerenciamento de uma biblioteca de jogos, desenvolvida com **Node.js** e **Express**. Projeto entregue como desafio prático na plataforma [DIO](https://www.dio.me/), com melhorias em relação ao repositório original [nodejs-express-api](https://github.com/digitalinnovationone/nodejs-express-api).

---

## ✨ Tecnologias utilizadas

| Tecnologia | Descrição |
|---|---|
| [Node.js](https://nodejs.org/) | Runtime JavaScript |
| [Express](https://expressjs.com/) | Framework web minimalista |
| [CORS](https://www.npmjs.com/package/cors) | Habilitação de requisições cross-origin |
| [UUID](https://www.npmjs.com/package/uuid) | Geração de IDs únicos |
| [Nodemon](https://nodemon.io/) | Hot reload em desenvolvimento |

---

## 📁 Estrutura do projeto

```
nodejs-express-api/
├── src/
│   ├── index.js                  # Entry point — configura o app Express
│   ├── data/
│   │   └── games.js              # Banco de dados em memória
│   ├── routes/
│   │   └── games.js              # Definição das rotas
│   ├── controllers/
│   │   └── gamesController.js    # Lógica de negócio de cada endpoint
│   └── middlewares/
│       ├── errorHandler.js       # Tratamento global de erros
│       └── logger.js             # Log colorido de requisições
├── .env
├── .gitignore
├── package.json
└── README.md
```

---

## ⚙️ Como executar localmente

### Pré-requisitos

- Node.js v18 ou superior
- npm

### Passo a passo

```bash
# 1. Clone o repositório
git clone https://github.com/seu-usuario/nodejs-express-api.git
cd nodejs-express-api

# 2. Instale as dependências
npm install

# 3. Execute em modo desenvolvimento (hot reload)
npm run dev

# 4. Ou execute em modo produção
npm start
```

A API estará disponível em `http://localhost:3000`.

---

## 📋 Endpoints

### Base URL: `/api/games`

| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/api/games` | Lista todos os jogos |
| GET | `/api/games/:id` | Busca um jogo pelo ID |
| POST | `/api/games` | Cadastra um novo jogo |
| PUT | `/api/games/:id` | Atualiza todos os dados de um jogo |
| PATCH | `/api/games/:id/complete` | Alterna o status de conclusão |
| DELETE | `/api/games/:id` | Remove um jogo |

### Query params disponíveis em `GET /api/games`

| Param | Exemplo | Descrição |
|-------|---------|-----------|
| `genre` | `?genre=RPG` | Filtra por gênero |
| `platform` | `?platform=PlayStation` | Filtra por plataforma |
| `completed` | `?completed=true` | Filtra por status de conclusão |
| `sort` | `?sort=rating` | Ordena por nota (maior primeiro) |

---

## 🧪 Exemplos de uso

### Listar todos os jogos
```http
GET http://localhost:3000/api/games
```

### Listar jogos de RPG ordenados por nota
```http
GET http://localhost:3000/api/games?genre=RPG&sort=rating
```

### Cadastrar novo jogo
```http
POST http://localhost:3000/api/games
Content-Type: application/json

{
  "title": "God of War Ragnarök",
  "genre": "Ação/Aventura",
  "platform": "PlayStation",
  "developer": "Santa Monica Studio",
  "releaseYear": 2022,
  "rating": 9.4
}
```

### Atualizar nota de um jogo
```http
PUT http://localhost:3000/api/games/:id
Content-Type: application/json

{
  "rating": 9.9
}
```

### Marcar jogo como concluído
```http
PATCH http://localhost:3000/api/games/:id/complete
```

### Remover jogo
```http
DELETE http://localhost:3000/api/games/:id
```

---

## 🚀 Melhorias em relação ao projeto original

Em comparação com o projeto base da DIO, este repositório inclui:

- **Arquitetura em camadas** — separação clara entre `routes`, `controllers` e `middlewares`
- **Controller dedicado** com validação de campos obrigatórios e regras de negócio
- **Query params de filtro** — genre, platform, completed e ordenação por rating
- **Rota PATCH extra** — toggle de status `completed` sem necessidade de PUT completo
- **Middleware de logger** personalizado com cores por status HTTP
- **Middleware de 404** para rotas inexistentes
- **Handler global de erros** com stack trace em desenvolvimento
- **IDs com UUID** em vez de inteiros sequenciais

---

## 🔗 Referências

- [Repositório original — DIO](https://github.com/digitalinnovationone/nodejs-express-api)
- [Documentação Express.js](https://expressjs.com/pt-br/)
- [Plataforma DIO](https://www.dio.me/)

---

## 👨‍💻 Autor

Desenvolvido como parte do bootcamp **Node.js** na **DIO — Digital Innovation One**.
